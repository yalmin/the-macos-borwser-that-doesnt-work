# Aperture Browser

Native macOS SwiftUI browser shell targeting macOS 26/27-era SDKs.

## Current build
- Real WKWebView page rendering
- HTTPS/HTTP navigation
- Address/search field
- Back/forward/reload controls
- Multiple tabs
- Vertical tab sidebar
- Control Center UI
- Settings and customization shell
- Local AI settings shell

## Important
The browser now uses Apple's WebKit (`WKWebView`) rather than a placeholder page.

The Local AI controls are configuration/UI only at this stage; they do not yet have permission-gated browser automation.
