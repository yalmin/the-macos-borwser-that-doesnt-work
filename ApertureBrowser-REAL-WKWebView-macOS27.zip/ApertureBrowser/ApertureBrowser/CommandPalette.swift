
import SwiftUI

struct CommandPalette: View {
    @EnvironmentObject var store: BrowserStore
    @Binding var isPresented: Bool
    @State private var query = ""

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Image(systemName: "magnifyingglass")
                TextField("Search commands, tabs and settings", text: $query)
                    .textFieldStyle(.plain)
                Text("esc").font(.caption2).foregroundStyle(.secondary)
            }
            .padding(11)
            Divider()
            CommandItem(icon: "sparkles", title: "Open Local AI") { store.openControl(.ai); isPresented = false }
            CommandItem(icon: "speaker.wave.2", title: "Audio Mixer") { store.openControl(.mixer); isPresented = false }
            CommandItem(icon: "paintbrush", title: "Customize") { store.openControl(.customize); isPresented = false }
            CommandItem(icon: "gearshape", title: "Open Settings") {
                let tab = BrowserTab(id: UUID(), title: "Settings", url: "aperture://settings", favicon: "gearshape")
                store.tabs.append(tab); store.selectedTab = tab.id; isPresented = false
            }
        }
        .frame(width: 500)
        .padding(10)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 18))
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(.white.opacity(0.15)))
        .shadow(radius: 30)
    }
}

struct CommandItem: View {
    let icon: String
    let title: String
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            Label(title, systemImage: icon)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(9)
        }
        .buttonStyle(.plain)
    }
}
