
import SwiftUI

struct ControlCenter: View {
    @EnvironmentObject var store: BrowserStore

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                if store.controlPage != .home {
                    Button { store.backControl() } label: {
                        Image(systemName: "chevron.left")
                    }
                    .buttonStyle(.borderless)
                }
                Text(title)
                    .font(.headline)
                Spacer()
                Button { store.controlCenterVisible = false } label: {
                    Image(systemName: "xmark")
                }
                .buttonStyle(.borderless)
            }
            .padding(.horizontal, 16)
            .padding(.top, 14)
            .padding(.bottom, 10)

            ScrollView {
                Group {
                    switch store.controlPage {
                    case .home: ControlHome()
                    case .ai: LocalAIPage()
                    case .mixer: AudioMixerPage()
                    case .customize: CustomizePage()
                    case .extensions: ExtensionsPage()
                    case .recording: RecordingPage()
                    case .privacy: PrivacyPage()
                    case .tools: BrowserToolsPage()
                    }
                }
                .padding(14)
            }
        }
        .frame(width: 410, height: 430)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 24))
        .overlay(RoundedRectangle(cornerRadius: 24).stroke(.white.opacity(0.14)))
        .shadow(color: .black.opacity(0.25), radius: 35, y: 18)
        .padding(.top, 12)
        .padding(.leading, 12)
    }

    var title: String {
        switch store.controlPage {
        case .home: "Control Center"
        case .ai: "Local AI"
        case .mixer: "Audio Mixer"
        case .customize: "Customize"
        case .extensions: "Extensions"
        case .recording: "Screen Recording"
        case .privacy: "Privacy"
        case .tools: "Browser Tools"
        }
    }
}

struct ControlHome: View {
    @EnvironmentObject var store: BrowserStore
    var body: some View {
        VStack(spacing: 10) {
            HStack(spacing: 10) {
                QuickToggle(title: store.settings.darkMode ? "Dark" : "Light", icon: store.settings.darkMode ? "moon.fill" : "sun.max.fill", active: true) { store.toggleTheme() }
                QuickToggle(title: "Focus", icon: "moon.zzz.fill", active: store.settings.focusMode) { store.settings.focusMode.toggle() }
                QuickToggle(title: "Sidebar", icon: "sidebar.left", active: true) {}
                QuickToggle(title: "Mute", icon: "speaker.slash.fill", active: false) {}
            }

            HStack(spacing: 10) {
                QuickToggle(title: "Reader", icon: "doc.plaintext", active: store.settings.readerMode) { store.settings.readerMode.toggle() }
                QuickToggle(title: "Compact", icon: "rectangle.compress.vertical", active: store.settings.compactTabs) { store.settings.compactTabs.toggle() }
                QuickToggle(title: "Privacy", icon: "hand.raised.fill", active: store.settings.privacyProtection) { store.settings.privacyProtection.toggle() }
                QuickToggle(title: "Record", icon: "record.circle", active: store.recording) { store.toggleRecording() }
            }

            VolumeControl()

            Divider().padding(.vertical, 2)

            HStack(spacing: 8) {
                DrillButton(icon: "sparkles", title: "Local AI") { store.openControl(.ai) }
                DrillButton(icon: "speaker.wave.2.fill", title: "Audio") { store.openControl(.mixer) }
                DrillButton(icon: "paintbrush.fill", title: "Customize") { store.openControl(.customize) }
            }
            HStack(spacing: 8) {
                DrillButton(icon: "puzzlepiece.extension.fill", title: "Extensions") { store.openControl(.extensions) }
                DrillButton(icon: "record.circle", title: "Recording") { store.openControl(.recording) }
                DrillButton(icon: "lock.shield.fill", title: "Privacy") { store.openControl(.privacy) }
            }

            HStack(spacing: 8) {
                DrillButton(icon: "square.split.2x1", title: "Split View") {}
                DrillButton(icon: "pip.enter", title: "Picture-in-Picture") {}
                DrillButton(icon: "wrench.and.screwdriver.fill", title: "Tools") { store.openControl(.tools) }
            }

            HStack {
                Text("Settings")
                Spacer()
                Button("Open in tab") {
                    let tab = BrowserTab(id: UUID(), title: "Settings", url: "aperture://settings", favicon: "gearshape")
                    store.tabs.append(tab)
                    store.selectedTab = tab.id
                    store.controlCenterVisible = false
                }
                .buttonStyle(.link)
            }
            .font(.caption)
            .padding(.top, 2)
        }
    }
}

struct QuickToggle: View {
    let title: String
    let icon: String
    let active: Bool
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            VStack(spacing: 6) {
                Image(systemName: icon).font(.title3)
                Text(title).font(.caption2)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 9)
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(
                        active
                        ? Color.accentColor.opacity(0.22)
                        : Color.secondary.opacity(0.12)
                    )
            )
        }
        .buttonStyle(.plain)
    }
}

struct DrillButton: View {
    let icon: String
    let title: String
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            Label(title, systemImage: icon)
                .font(.caption)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 9)
                .background(.quaternary, in: RoundedRectangle(cornerRadius: 11))
        }
        .buttonStyle(.plain)
    }
}

struct VolumeControl: View {
    @EnvironmentObject var store: BrowserStore
    var body: some View {
        HStack {
            Image(systemName: "speaker.wave.2.fill")
            Slider(value: $store.masterVolume)
            Text("\(Int(store.masterVolume * 100))%")
                .font(.caption.monospacedDigit())
                .frame(width: 38, alignment: .trailing)
        }
        .padding(.horizontal, 4)
    }
}
