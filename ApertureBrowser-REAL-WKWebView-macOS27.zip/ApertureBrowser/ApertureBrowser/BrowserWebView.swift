
import SwiftUI
import WebKit

struct BrowserWebView: NSViewRepresentable {
    let url: String

    func makeNSView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.websiteDataStore = .default()
        let webView = WKWebView(frame: .zero, configuration: config)
        webView.allowsBackForwardNavigationGestures = true
        load(url, into: webView)
        return webView
    }

    func updateNSView(_ webView: WKWebView, context: Context) {
        guard let current = webView.url?.absoluteString else {
            load(url, into: webView)
            return
        }
        if normalize(current) != normalize(url) {
            load(url, into: webView)
        }
    }

    private func normalize(_ value: String) -> String {
        value.trimmingCharacters(in: .whitespacesAndNewlines)
            .trimmingCharacters(in: CharacterSet(charactersIn: "/"))
    }

    private func load(_ value: String, into webView: WKWebView) {
        let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
        let target: URL?

        if let direct = URL(string: trimmed),
           direct.scheme == "http" || direct.scheme == "https" {
            target = direct
        } else if let encoded = trimmed.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
                  let search = URL(string: "https://www.google.com/search?q=\(encoded)") {
            target = search
        } else {
            target = URL(string: "https://www.google.com")
        }

        if let target {
            webView.load(URLRequest(url: target))
        }
    }
}

final class WebViewController: NSObject, WKNavigationDelegate {
    let webView: WKWebView

    init(url: String) {
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .default()
        self.webView = WKWebView(frame: .zero, configuration: configuration)
        super.init()
        webView.navigationDelegate = self
        webView.allowsBackForwardNavigationGestures = true
        load(url)
    }

    func load(_ value: String) {
        let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
        let target: URL?

        if let u = URL(string: trimmed),
           u.scheme == "http" || u.scheme == "https" {
            target = u
        } else if let q = trimmed.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) {
            target = URL(string: "https://www.google.com/search?q=\(q)")
        } else {
            target = URL(string: "https://www.google.com")
        }

        if let target {
            webView.load(URLRequest(url: target))
        }
    }

    func goBack() { if webView.canGoBack { webView.goBack() } }
    func goForward() { if webView.canGoForward { webView.goForward() } }
    func reload() { webView.reload() }
}

struct RealBrowserView: NSViewRepresentable {
    @ObservedObject var store: BrowserStore

    func makeNSView(context: Context) -> WKWebView {
        let webView = WKWebView(frame: .zero)
        webView.allowsBackForwardNavigationGestures = true
        webView.navigationDelegate = context.coordinator
        context.coordinator.webView = webView
        context.coordinator.load(store.currentTab?.url ?? "https://www.google.com")
        return webView
    }

    func updateNSView(_ webView: WKWebView, context: Context) {
        context.coordinator.store = store
        guard let tab = store.currentTab else { return }
        let requested = tab.url
        if requested != context.coordinator.lastRequestedURL {
            context.coordinator.load(requested)
        }
    }

    func makeCoordinator() -> Coordinator {
        Coordinator(store: store)
    }

    final class Coordinator: NSObject, WKNavigationDelegate {
        var store: BrowserStore
        weak var webView: WKWebView?
        var lastRequestedURL = ""

        init(store: BrowserStore) {
            self.store = store
        }

        func load(_ value: String) {
            let value = value.trimmingCharacters(in: .whitespacesAndNewlines)
            let url: URL?

            if let u = URL(string: value), u.scheme == "http" || u.scheme == "https" {
                url = u
            } else if let q = value.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) {
                url = URL(string: "https://www.google.com/search?q=\(q)")
            } else {
                url = URL(string: "https://www.google.com")
            }

            guard let url, let webView else { return }
            lastRequestedURL = value
            webView.load(URLRequest(url: url))
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            let actual = webView.url?.absoluteString ?? ""
            lastRequestedURL = actual
            store.updateCurrentURL(actual, title: webView.title ?? actual)
        }
    }
}
