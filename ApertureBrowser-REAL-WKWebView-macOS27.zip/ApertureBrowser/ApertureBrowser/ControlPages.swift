
import SwiftUI

struct LocalAIPage: View {
    @EnvironmentObject var store: BrowserStore
    @State private var testing = false
    @State private var result = ""

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Toggle("Enable Local AI", isOn: $store.ai.enabled)
            Text("OpenAI-compatible local endpoint")
                .font(.caption)
                .foregroundStyle(.secondary)
            TextField("http://localhost:1234/v1", text: $store.ai.endpoint)
                .textFieldStyle(.roundedBorder)
            TextField("Model (optional)", text: $store.ai.model)
                .textFieldStyle(.roundedBorder)
            HStack {
                Button(testing ? "Testing…" : "Test connection") {
                    testing = true
                    result = "Endpoint check ready to run from the native browser service."
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { testing = false }
                }
                .disabled(testing)
                Text(result).font(.caption).foregroundStyle(.secondary)
            }
            Divider()
            Text("Website access").font(.subheadline.weight(.semibold))
            PermissionToggle("Allow websites to be accessed", icon: "globe", value: $store.ai.allowWebsites)
            PermissionToggle("Allow navigation", icon: "arrow.up.right", value: $store.ai.allowNavigation)
            PermissionToggle("Allow clicking and typing", icon: "cursorarrow.click", value: $store.ai.allowClicksTyping)
            PermissionToggle("Allow reading page content", icon: "doc.text", value: $store.ai.allowReadContent)
            Text("Permissions are explicit. The AI service cannot bypass macOS or website security controls.")
                .font(.caption2)
                .foregroundStyle(.tertiary)
        }
    }
}

struct PermissionToggle: View {
    let title: String
    let icon: String
    @Binding var value: Bool
    init(_ title: String, icon: String, value: Binding<Bool>) {
        self.title = title; self.icon = icon; self._value = value
    }
    var body: some View {
        Toggle(isOn: $value) {
            Label(title, systemImage: icon)
                .font(.caption)
        }
    }
}

struct AudioMixerPage: View {
    @EnvironmentObject var store: BrowserStore
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("Master").font(.caption.weight(.semibold))
                Slider(value: $store.masterVolume)
                Text("\(Int(store.masterVolume * 100))%").font(.caption.monospacedDigit())
            }
            Divider()
            ForEach(store.tabs) { tab in
                VStack(spacing: 5) {
                    HStack {
                        Image(systemName: tab.favicon)
                        Text(tab.title).lineLimit(1)
                        Spacer()
                        if tab.isPlaying { Image(systemName: "waveform") }
                        Button {
                            if let i = store.tabs.firstIndex(where: {$0.id == tab.id}) {
                                store.tabs[i].isMuted.toggle()
                            }
                        } label: {
                            Image(systemName: tab.isMuted ? "speaker.slash.fill" : "speaker.wave.2.fill")
                        }
                        .buttonStyle(.borderless)
                    }
                    Slider(value: Binding(
                        get: { tab.volume },
                        set: { store.updateVolume(tab.id, $0) }
                    ))
                }
                .padding(8)
                .background(.quaternary, in: RoundedRectangle(cornerRadius: 10))
            }
        }
    }
}

struct CustomizePage: View {
    @EnvironmentObject var store: BrowserStore
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Appearance").font(.subheadline.weight(.semibold))
            Picker("Accent", selection: $store.settings.accent) {
                Text("Blue").tag("Blue"); Text("Purple").tag("Purple"); Text("Green").tag("Green"); Text("Orange").tag("Orange")
            }
            SliderRow(title: "Page tint", value: $store.settings.pageTint, range: 0...1)
            SliderRow(title: "Sidebar opacity", value: $store.settings.sidebarOpacity, range: 0.2...1)
            SliderRow(title: "Blur", value: $store.settings.blur, range: 0...40)
            SliderRow(title: "Corner radius", value: $store.settings.cornerRadius, range: 4...30)
            Toggle("Sidebar animations", isOn: $store.settings.sidebarAnimations)
            Toggle("Panel animations", isOn: $store.settings.panelAnimations)
            Toggle("Compact tabs", isOn: $store.settings.compactTabs)
            Button("Reset appearance") { store.settings = BrowserSettings() }
                .buttonStyle(.borderless)
        }
    }
}

struct SliderRow: View {
    let title: String
    @Binding var value: Double
    let range: ClosedRange<Double>
    var body: some View {
        HStack {
            Text(title).font(.caption)
            Slider(value: $value, in: range)
            Text(String(format: "%.0f", value)).font(.caption.monospacedDigit()).frame(width: 34)
        }
    }
}

struct ExtensionsPage: View {
    @EnvironmentObject var store: BrowserStore
    var body: some View {
        VStack(spacing: 8) {
            ForEach($store.extensions) { $ext in
                HStack {
                    Image(systemName: "puzzlepiece.extension.fill")
                    VStack(alignment: .leading) {
                        Text(ext.name).font(.caption.weight(.semibold))
                        Text(ext.detail).font(.caption2).foregroundStyle(.secondary)
                    }
                    Spacer()
                    Toggle("", isOn: $ext.enabled).labelsHidden()
                    Button("Configure") {}
                        .buttonStyle(.borderless)
                        .font(.caption)
                }
                .padding(9)
                .background(.quaternary, in: RoundedRectangle(cornerRadius: 11))
            }
            Button("Add Extension") {}
                .frame(maxWidth: .infinity)
        }
    }
}

struct RecordingPage: View {
    @EnvironmentObject var store: BrowserStore
    var body: some View {
        VStack(alignment: .leading, spacing: 13) {
            HStack {
                Circle().fill(store.recording ? .red : .secondary).frame(width: 9)
                Text(store.recording ? "Recording browser window" : "Ready to record")
                Spacer()
            }
            Button(store.recording ? "Stop Recording" : "Start Recording") {
                store.toggleRecording()
            }
            .buttonStyle(.borderedProminent)
            Toggle("Microphone", isOn: .constant(false))
            Toggle("System audio", isOn: .constant(true))
            Picker("Capture", selection: .constant("Browser Window")) {
                Text("Browser Window").tag("Browser Window")
                Text("Entire Display").tag("Entire Display")
            }
            Picker("Quality", selection: .constant("High")) {
                Text("Standard").tag("Standard"); Text("High").tag("High"); Text("Ultra").tag("Ultra")
            }
            Text("ScreenCaptureKit integration is intended for the native target and requires macOS Screen Recording permission.")
                .font(.caption2).foregroundStyle(.tertiary)
        }
    }
}

struct PrivacyPage: View {
    @EnvironmentObject var store: BrowserStore
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Toggle("Block trackers", isOn: $store.settings.blockTrackers)
            Toggle("Prevent cross-site tracking", isOn: $store.settings.privacyProtection)
            Toggle("Hide IP from known trackers", isOn: .constant(true))
            Toggle("Clear browsing data on quit", isOn: .constant(false))
            Divider()
            Text("Per-site permissions").font(.subheadline.weight(.semibold))
            Text("Permissions are controlled per website and can be reviewed from the address bar.")
                .font(.caption).foregroundStyle(.secondary)
        }
    }
}

struct BrowserToolsPage: View {
    var body: some View {
        VStack(spacing: 8) {
            ToolRow(icon: "camera", title: "Screenshot", detail: "Capture visible browser content")
            ToolRow(icon: "doc.on.doc", title: "Duplicate tab", detail: "Open a copy of the current page")
            ToolRow(icon: "rectangle.split.2x1", title: "Split view", detail: "Two pages side by side")
            ToolRow(icon: "translate", title: "Translate page", detail: "Translate the current page")
            ToolRow(icon: "pip.enter", title: "Picture in Picture", detail: "Float supported video")
            ToolRow(icon: "clock.arrow.circlepath", title: "Recently closed", detail: "Restore a closed tab")
        }
    }
}

struct ToolRow: View {
    let icon: String
    let title: String
    let detail: String
    var body: some View {
        HStack {
            Image(systemName: icon).frame(width: 22)
            VStack(alignment: .leading) {
                Text(title).font(.caption.weight(.semibold))
                Text(detail).font(.caption2).foregroundStyle(.secondary)
            }
            Spacer()
            Image(systemName: "chevron.right").font(.caption2).foregroundStyle(.tertiary)
        }
        .padding(9)
        .background(.quaternary, in: RoundedRectangle(cornerRadius: 10))
    }
}
