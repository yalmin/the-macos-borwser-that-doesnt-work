
import SwiftUI
import Combine

@MainActor
final class BrowserStore: ObservableObject {
    @Published var tabs: [BrowserTab] = [
        BrowserTab(id: UUID(), title: "Aperture", url: "https://www.apple.com", favicon: "safari"),
        BrowserTab(id: UUID(), title: "New Tab", url: "https://www.google.com", favicon: "globe")
    ]
    @Published var selectedTab: UUID?
    @Published var controlCenterVisible = false
    @Published var controlPage: ControlPage = .home
    @Published var settings = BrowserSettings()
    @Published var ai = AISettings()
    @Published var extensions = [
        BrowserExtension(name: "Aperture Ad Shield", detail: "Tracker and ad protection", enabled: true, permissions: "Web pages"),
        BrowserExtension(name: "Dark Reader", detail: "Page appearance", enabled: false, permissions: "Read pages"),
        BrowserExtension(name: "Local Assistant", detail: "Local AI browser control", enabled: false, permissions: "Pages + navigation")
    ]
    @Published var masterVolume = 0.78
    @Published var recording = false
    @Published var status = "Ready"

    init() {
        selectedTab = tabs.first?.id
    }

    var currentTab: BrowserTab? {
        tabs.first(where: { $0.id == selectedTab })
    }

    func newTab() {
        let tab = BrowserTab(id: UUID(), title: "New Tab", url: "https://www.google.com", favicon: "globe")
        tabs.append(tab)
        selectedTab = tab.id
    }

    func closeTab(_ tab: BrowserTab) {
        guard tabs.count > 1 else { return }
        let wasSelected = selectedTab == tab.id
        tabs.removeAll { $0.id == tab.id }
        if wasSelected { selectedTab = tabs.last?.id }
    }

    func updateVolume(_ tabID: UUID, _ value: Double) {
        guard let i = tabs.firstIndex(where: { $0.id == tabID }) else { return }
        tabs[i].volume = value
    }

    func openControl(_ page: ControlPage) {
        controlPage = page
        controlCenterVisible = true
    }

    func backControl() {
        controlPage = .home
    }

    func updateCurrentURL(_ url: String, title: String) {
        guard let id = selectedTab,
              let index = tabs.firstIndex(where: { $0.id == id }) else { return }
        tabs[index].url = url
        tabs[index].title = title.isEmpty ? url : title
    }

    func navigate(_ text: String) {
        guard let id = selectedTab,
              let index = tabs.firstIndex(where: { $0.id == id }) else { return }
        tabs[index].url = text
    }

    func toggleTheme() {
        settings.darkMode.toggle()
    }

    func toggleRecording() {
        recording.toggle()
        status = recording ? "Recording browser window…" : "Recording saved"
    }
}
