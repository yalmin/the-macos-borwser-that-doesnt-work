
import SwiftUI
import WebKit

struct BrowserWindow: View {
    @EnvironmentObject var store: BrowserStore
    @State private var address = ""

    var body: some View {
        ZStack(alignment: .topLeading) {
            HStack(spacing: 0) {
                TabSidebar()

                VStack(spacing: 0) {
                    BrowserToolbar(address: $address)
                    Divider()
                    RealBrowserView(store: store)
                }
            }
            .onAppear {
                address = store.currentTab?.url ?? "https://www.google.com"
            }

            TopLeftTrigger()

            if store.controlCenterVisible {
                ControlCenter()
                    .transition(.move(edge: .top).combined(with: .opacity))
                    .zIndex(10)
            }

            CommandPalette()
        }
        .background(Color(nsColor: .windowBackgroundColor))
        .onChange(of: store.selectedTab) { _, _ in
            address = store.currentTab?.url ?? ""
        }
    }
}

struct BrowserToolbar: View {
    @EnvironmentObject var store: BrowserStore
    @Binding var address: String

    var body: some View {
        HStack(spacing: 8) {
            Button(action: goBack) { Image(systemName: "chevron.left") }
                .buttonStyle(.plain)
            Button(action: goForward) { Image(systemName: "chevron.right") }
                .buttonStyle(.plain)
            Button(action: reload) { Image(systemName: "arrow.clockwise") }
                .buttonStyle(.plain)

            HStack {
                Image(systemName: "lock.fill")
                    .foregroundStyle(.secondary)

                TextField("Search or enter website", text: $address)
                    .textFieldStyle(.plain)
                    .onSubmit {
                        store.navigate(address)
                    }
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 7)
            .background(.quaternary, in: Capsule())

            Button {
                store.controlCenterVisible.toggle()
            } label: {
                Image(systemName: "slider.horizontal.3")
            }
            .buttonStyle(.plain)

            Button {
                store.newTab()
                address = store.currentTab?.url ?? ""
            } label: {
                Image(systemName: "plus")
            }
            .buttonStyle(.plain)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 9)
    }

    private func goBack() {
        NotificationCenter.default.post(name: .browserGoBack, object: nil)
    }

    private func goForward() {
        NotificationCenter.default.post(name: .browserGoForward, object: nil)
    }

    private func reload() {
        NotificationCenter.default.post(name: .browserReload, object: nil)
    }
}

extension Notification.Name {
    static let browserGoBack = Notification.Name("Aperture.browserGoBack")
    static let browserGoForward = Notification.Name("Aperture.browserGoForward")
    static let browserReload = Notification.Name("Aperture.browserReload")
}

struct TabSidebar: View {
    @EnvironmentObject var store: BrowserStore

    var body: some View {
        VStack(spacing: 8) {
            ForEach(store.tabs) { tab in
                Button {
                    store.selectedTab = tab.id
                } label: {
                    HStack(spacing: 8) {
                        Image(systemName: tab.favicon)
                        Text(tab.title)
                            .lineLimit(1)
                        Spacer()
                        if tab.isMuted {
                            Image(systemName: "speaker.slash.fill")
                                .font(.caption)
                        }
                    }
                    .padding(9)
                    .background(
                        RoundedRectangle(cornerRadius: 10)
                            .fill(store.selectedTab == tab.id ? Color.accentColor.opacity(0.18) : .clear)
                    )
                }
                .buttonStyle(.plain)
            }

            Spacer()

            Button {
                store.newTab()
            } label: {
                Image(systemName: "plus")
                    .frame(maxWidth: .infinity)
                    .padding(9)
            }
            .buttonStyle(.plain)
        }
        .padding(8)
        .frame(width: store.settings.compactTabs ? 72 : 190)
        .background(.ultraThinMaterial)
    }
}

struct TopLeftTrigger: View {
    @EnvironmentObject var store: BrowserStore

    var body: some View {
        Color.clear
            .frame(width: 70, height: 35)
            .contentShape(Rectangle())
            .onHover { hovering in
                if hovering {
                    withAnimation(.easeOut(duration: 0.18)) {
                        store.controlCenterVisible = true
                    }
                }
            }
    }
}
