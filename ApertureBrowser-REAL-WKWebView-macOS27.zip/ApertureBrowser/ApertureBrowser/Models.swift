
import Foundation

struct BrowserTab: Identifiable, Equatable {
    let id: UUID
    var title: String
    var url: String
    var isPinned: Bool = false
    var isMuted: Bool = false
    var volume: Double = 1
    var isPlaying: Bool = false
    var favicon: String = "globe"
}

enum ControlPage: Equatable {
    case home, ai, mixer, customize, extensions, recording, privacy, tools
}

struct BrowserExtension: Identifiable {
    let id = UUID()
    var name: String
    var detail: String
    var enabled: Bool
    var permissions: String
}

struct AISettings {
    var endpoint = "http://localhost:1234/v1"
    var model = ""
    var enabled = false
    var allowWebsites = false
    var allowNavigation = false
    var allowClicksTyping = false
    var allowReadContent = false
}

struct BrowserSettings {
    var darkMode = true
    var accent = "Blue"
    var pageTint = 0.0
    var tabDensity = 0.55
    var sidebarOpacity = 0.78
    var sidebarAnimations = true
    var panelAnimations = true
    var blur = 22.0
    var cornerRadius = 18.0
    var compactTabs = false
    var focusMode = false
    var readerMode = false
    var privacyProtection = true
    var blockTrackers = true
    var searchEngine = "DuckDuckGo"
    var downloadFolder = "~/Downloads"
}
