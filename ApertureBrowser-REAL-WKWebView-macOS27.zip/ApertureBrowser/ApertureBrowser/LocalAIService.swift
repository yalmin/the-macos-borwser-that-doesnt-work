
import Foundation

actor LocalAIService {
    struct Message: Codable {
        let role: String
        let content: String
    }

    struct Request: Codable {
        let model: String
        let messages: [Message]
        let temperature: Double
    }

    struct Response: Codable {
        struct Choice: Codable {
            struct Message: Codable { let role: String; let content: String }
            let message: Message
        }
        let choices: [Choice]
    }

    func chat(endpoint: String, model: String, prompt: String) async throws -> String {
        let base = endpoint.hasSuffix("/") ? String(endpoint.dropLast()) : endpoint
        guard let url = URL(string: base + "/chat/completions") else {
            throw URLError(.badURL)
        }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONEncoder().encode(
            Request(model: model, messages: [.init(role: "user", content: prompt)], temperature: 0.2)
        )
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse, 200..<300 ~= http.statusCode else {
            throw URLError(.badServerResponse)
        }
        return try JSONDecoder().decode(Response.self, from: data).choices.first?.message.content ?? ""
    }
}
