
import SwiftUI

@main
struct ApertureBrowserApp: App {
    @StateObject private var store = BrowserStore()

    var body: some Scene {
        WindowGroup("Aperture Browser") {
            BrowserWindow()
                .environmentObject(store)
                .frame(minWidth: 1050, minHeight: 680)
        }
        .windowStyle(.hiddenTitleBar)
        .commands {
            CommandGroup(after: .newItem) {
                Button("New Tab") { store.newTab() }
                    .keyboardShortcut("t", modifiers: .command)
                Button("Control Center") { store.controlCenterVisible.toggle() }
                    .keyboardShortcut(",", modifiers: [.command, .shift])
            }
        }
    }
}
