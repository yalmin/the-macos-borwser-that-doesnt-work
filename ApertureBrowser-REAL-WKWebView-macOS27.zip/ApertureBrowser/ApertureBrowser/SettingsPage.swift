
import SwiftUI

struct SettingsPage: View {
    @EnvironmentObject var store: BrowserStore
    @State private var section = "General"

    let sections = ["General","Appearance","Tabs","Sidebar","Privacy & Security","Search","Downloads","Performance","Local AI","Extensions","Audio","Recording","Shortcuts","Profiles","Advanced"]

    var body: some View {
        HStack(spacing: 0) {
            List(sections, id: \.self, selection: $section) {
                Text($0)
            }
            .listStyle(.sidebar)
            .frame(width: 205)

            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    Text(section).font(.system(size: 30, weight: .semibold, design: .rounded))
                    settingsBody
                }
                .frame(maxWidth: 720, alignment: .leading)
                .padding(38)
            }
        }
    }

    @ViewBuilder
    var settingsBody: some View {
        switch section {
        case "General":
            SettingGroup("Startup") {
                Toggle("Restore previous session", isOn: .constant(true))
                Toggle("Open new tabs beside active tab", isOn: .constant(true))
                Toggle("Confirm before closing multiple tabs", isOn: .constant(false))
            }
        case "Appearance":
            SettingGroup("Theme") {
                Toggle("Dark appearance", isOn: $store.settings.darkMode)
                Picker("Accent color", selection: $store.settings.accent) {
                    Text("Blue").tag("Blue"); Text("Purple").tag("Purple"); Text("Green").tag("Green"); Text("Orange").tag("Orange")
                }
                SliderRow(title: "Page tint", value: $store.settings.pageTint, range: 0...1)
                SliderRow(title: "Glass blur", value: $store.settings.blur, range: 0...40)
            }
        case "Tabs":
            SettingGroup("Tab behavior") {
                Toggle("Compact tabs", isOn: $store.settings.compactTabs)
                Toggle("Show audio indicators", isOn: .constant(true))
                Toggle("Keep pinned tabs when closing window", isOn: .constant(true))
            }
        case "Sidebar":
            SettingGroup("Vertical sidebar") {
                SliderRow(title: "Opacity", value: $store.settings.sidebarOpacity, range: 0.2...1)
                Toggle("Animate tab changes", isOn: $store.settings.sidebarAnimations)
                Toggle("Show labels", isOn: .constant(true))
            }
        case "Privacy & Security":
            SettingGroup("Protection") {
                Toggle("Block trackers", isOn: $store.settings.blockTrackers)
                Toggle("Prevent cross-site tracking", isOn: $store.settings.privacyProtection)
                Toggle("Ask before allowing sensitive permissions", isOn: .constant(true))
            }
        case "Search":
            SettingGroup("Search engine") {
                Picker("Default", selection: $store.settings.searchEngine) {
                    Text("DuckDuckGo").tag("DuckDuckGo"); Text("Google").tag("Google"); Text("Bing").tag("Bing")
                }
            }
        case "Downloads":
            SettingGroup("Files") {
                TextField("Download folder", text: $store.settings.downloadFolder)
                Toggle("Ask where to save each file", isOn: .constant(false))
            }
        case "Local AI":
            SettingGroup("Local model") {
                TextField("Endpoint", text: $store.ai.endpoint)
                TextField("Model", text: $store.ai.model)
                Toggle("Enable local AI", isOn: $store.ai.enabled)
                Toggle("Allow website access", isOn: $store.ai.allowWebsites)
                Toggle("Allow navigation", isOn: $store.ai.allowNavigation)
                Toggle("Allow clicking and typing", isOn: $store.ai.allowClicksTyping)
                Toggle("Allow reading page content", isOn: $store.ai.allowReadContent)
            }
        case "Extensions":
            SettingGroup("Installed") {
                ForEach($store.extensions) { $ext in
                    Toggle(ext.name, isOn: $ext.enabled)
                }
            }
        case "Audio":
            SettingGroup("Browser audio") {
                SliderRow(title: "Master volume", value: $store.masterVolume, range: 0...1)
                Toggle("Normalize tab volume", isOn: .constant(false))
                Toggle("Show per-tab audio controls", isOn: .constant(true))
            }
        case "Recording":
            SettingGroup("Capture") {
                Toggle("System audio", isOn: .constant(true))
                Toggle("Microphone", isOn: .constant(false))
                Picker("Quality", selection: .constant("High")) {
                    Text("Standard").tag("Standard"); Text("High").tag("High"); Text("Ultra").tag("Ultra")
                }
            }
        case "Performance":
            SettingGroup("Performance") {
                Toggle("Use hardware acceleration", isOn: .constant(true))
                Toggle("Reduce animations on low power", isOn: .constant(true))
                Toggle("Unload inactive tabs", isOn: .constant(true))
            }
        default:
            SettingGroup(section) {
                Text("More browser controls will appear here in the native build.")
                    .foregroundStyle(.secondary)
            }
        }
    }
}

struct SettingGroup<Content: View>: View {
    let title: String
    @ViewBuilder let content: () -> Content
    init(_ title: String, @ViewBuilder content: @escaping () -> Content) {
        self.title = title; self.content = content
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(title).font(.headline)
            VStack(alignment: .leading, spacing: 12) { content() }
                .padding(16)
                .background(.quaternary, in: RoundedRectangle(cornerRadius: 16))
        }
    }
}
