# Aperture Browser — macOS 27 / Xcode

Open `ApertureBrowser.xcodeproj` in Xcode.

This is a native SwiftUI browser UI prototype with:
- Vertical tabs
- Top-left Control Center
- Liquid Glass-style materials
- Nested Local AI settings for OpenAI-compatible localhost endpoints
- Per-tab audio mixer
- Customize panel
- Extensions panel
- Screen recording controls
- Privacy and browser tools
- Separate Settings tab
- Command palette
- Persistent browser-state model

The Local AI service targets endpoints such as:
`http://localhost:1234/v1`

The UI deliberately requires explicit permissions before the local AI can be configured for website access, navigation, page reading, or clicks/typing.

Next native implementation steps for a production browser:
- Replace the placeholder browser content with WKWebView instances per tab.
- Connect WKWebView navigation/website permissions.
- Add ScreenCaptureKit recording implementation.
- Add AVAudioEngine/tab audio routing where supported.
- Add a native WebExtension host.


Build note: Quick-toggle backgrounds use explicit Color values to avoid SwiftUI `some ShapeStyle` ternary inference errors.
