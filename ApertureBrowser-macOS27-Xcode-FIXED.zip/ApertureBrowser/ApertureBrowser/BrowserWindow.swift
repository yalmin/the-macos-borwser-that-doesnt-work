
import SwiftUI

struct BrowserWindow: View {
    @EnvironmentObject var store: BrowserStore
    @State private var address = ""
    @State private var showCommandPalette = false

    var body: some View {
        ZStack(alignment: .topLeading) {
            HStack(spacing: 0) {
                TabSidebar()
                VStack(spacing: 0) {
                    BrowserToolbar(address: $address, showCommandPalette: $showCommandPalette)
                    BrowserContent()
                }
            }
            .background(.background)

            TopLeftTrigger()
                .zIndex(20)

            if store.controlCenterVisible {
                ControlCenter()
                    .transition(.move(edge: .top).combined(with: .opacity))
                    .zIndex(30)
            }

            if showCommandPalette {
                CommandPalette(isPresented: $showCommandPalette)
                    .zIndex(40)
            }
        }
        .preferredColorScheme(store.settings.darkMode ? .dark : .light)
        .animation(.snappy(duration: 0.22), value: store.controlCenterVisible)
        .animation(.snappy(duration: 0.2), value: store.controlPage)
        .onAppear { address = store.currentTab?.url ?? "" }
    }
}

struct TopLeftTrigger: View {
    @EnvironmentObject var store: BrowserStore
    var body: some View {
        Button {
            store.openControl(.home)
        } label: {
            Color.clear.frame(width: 54, height: 38)
        }
        .buttonStyle(.plain)
        .onHover { inside in
            if inside && !store.controlCenterVisible {
                store.openControl(.home)
            }
        }
        .help("Control Center")
    }
}

struct TabSidebar: View {
    @EnvironmentObject var store: BrowserStore

    var body: some View {
        VStack(spacing: 8) {
            HStack {
                Image(systemName: "circle.hexagongrid.fill")
                    .font(.title3)
                Text("APERTURE")
                    .font(.system(size: 11, weight: .bold, design: .rounded))
                    .tracking(1.5)
                Spacer()
                Button { store.newTab() } label: {
                    Image(systemName: "plus")
                }
                .buttonStyle(.borderless)
            }
            .padding(.horizontal, 12)
            .padding(.top, 10)

            Divider().opacity(0.35)

            ScrollView {
                VStack(spacing: 5) {
                    ForEach(store.tabs) { tab in
                        TabRow(tab: tab)
                    }
                }
                .padding(7)
            }

            Spacer(minLength: 4)

            VStack(spacing: 2) {
                SidebarButton(icon: "square.split.2x1", title: "Split View") {}
                SidebarButton(icon: "arrow.down.circle", title: "Downloads") {}
                SidebarButton(icon: "gearshape", title: "Settings") {
                    let tab = BrowserTab(id: UUID(), title: "Settings", url: "aperture://settings", favicon: "gearshape")
                    store.tabs.append(tab)
                    store.selectedTab = tab.id
                }
            }
            .padding(.bottom, 10)
        }
        .frame(width: store.settings.compactTabs ? 72 : 190)
        .background(.thinMaterial)
        .overlay(alignment: .trailing) { Divider() }
    }
}

struct TabRow: View {
    @EnvironmentObject var store: BrowserStore
    let tab: BrowserTab

    var active: Bool { store.selectedTab == tab.id }

    var body: some View {
        Button {
            store.selectedTab = tab.id
        } label: {
            HStack(spacing: 9) {
                Image(systemName: tab.favicon)
                    .frame(width: 18)
                Text(tab.title)
                    .lineLimit(1)
                    .frame(maxWidth: .infinity, alignment: .leading)
                if tab.isPlaying { Image(systemName: "waveform") }
                Button { store.closeTab(tab) } label: {
                    Image(systemName: "xmark")
                        .font(.system(size: 9, weight: .bold))
                }
                .buttonStyle(.plain)
            }
            .padding(.horizontal, 9)
            .padding(.vertical, 8)
            .background(active ? AnyShapeStyle(.quaternary) : AnyShapeStyle(.clear), in: RoundedRectangle(cornerRadius: 10))
        }
        .buttonStyle(.plain)
        .contextMenu {
            Button(tab.isMuted ? "Unmute" : "Mute") {
                if let i = store.tabs.firstIndex(where: {$0.id == tab.id}) {
                    store.tabs[i].isMuted.toggle()
                }
            }
            Button("Duplicate") {
                let copy = BrowserTab(id: UUID(), title: tab.title + " Copy", url: tab.url, favicon: tab.favicon)
                store.tabs.append(copy)
                store.selectedTab = copy.id
            }
            Button(tab.isPinned ? "Unpin Tab" : "Pin Tab") {
                if let i = store.tabs.firstIndex(where: {$0.id == tab.id}) {
                    store.tabs[i].isPinned.toggle()
                }
            }
            Divider()
            Button("Close Tab") { store.closeTab(tab) }
        }
    }
}

struct SidebarButton: View {
    let icon: String
    let title: String
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            Label(title, systemImage: icon)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, 11)
                .padding(.vertical, 6)
        }
        .buttonStyle(.plain)
    }
}

struct BrowserToolbar: View {
    @EnvironmentObject var store: BrowserStore
    @Binding var address: String
    @Binding var showCommandPalette: Bool

    var body: some View {
        HStack(spacing: 8) {
            Button {} label: { Image(systemName: "chevron.left") }
            Button {} label: { Image(systemName: "chevron.right") }
            Button {} label: { Image(systemName: "arrow.clockwise") }

            HStack(spacing: 8) {
                Image(systemName: "lock.fill").font(.caption2)
                TextField("Search or enter website", text: $address)
                    .textFieldStyle(.plain)
                Image(systemName: "sparkle")
                    .foregroundStyle(.secondary)
            }
            .padding(.horizontal, 11)
            .padding(.vertical, 7)
            .background(.quaternary, in: Capsule())

            Button { showCommandPalette = true } label: {
                Image(systemName: "command")
            }
            .help("Command Palette")

            Button { store.openControl(.home) } label: {
                Image(systemName: "slider.horizontal.3")
            }
        }
        .buttonStyle(.borderless)
        .padding(.horizontal, 14)
        .padding(.vertical, 10)
        .background(.bar)
    }
}

struct BrowserContent: View {
    @EnvironmentObject var store: BrowserStore

    var body: some View {
        Group {
            if store.currentTab?.url == "aperture://settings" {
                SettingsPage()
            } else {
                WelcomePage()
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(.background)
    }
}

struct WelcomePage: View {
    @EnvironmentObject var store: BrowserStore
    var body: some View {
        ZStack {
            LinearGradient(
                colors: [Color.accentColor.opacity(0.18), .clear, Color.purple.opacity(0.08)],
                startPoint: .topLeading, endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            VStack(spacing: 18) {
                Image(systemName: "circle.hexagongrid.fill")
                    .font(.system(size: 54))
                    .symbolRenderingMode(.hierarchical)
                Text("Aperture")
                    .font(.system(size: 40, weight: .semibold, design: .rounded))
                Text("A browser built around the space between your tabs.")
                    .foregroundStyle(.secondary)
                HStack(spacing: 8) {
                    FeaturePill(icon: "sidebar.left", text: "Vertical tabs")
                    FeaturePill(icon: "sparkles", text: "Local AI")
                    FeaturePill(icon: "slider.horizontal.3", text: "Control Center")
                }
                Text("Move your pointer into the top-left corner")
                    .font(.caption)
                    .foregroundStyle(.tertiary)
            }
        }
    }
}

struct FeaturePill: View {
    let icon: String
    let text: String
    var body: some View {
        Label(text, systemImage: icon)
            .font(.caption)
            .padding(.horizontal, 10)
            .padding(.vertical, 7)
            .background(.quaternary, in: Capsule())
    }
}
