import SwiftUI
import AppKit
import Combine

enum AppAppearance: String, CaseIterable, Identifiable {
    case system, light, dark
    var id: String { rawValue }
}

/// Central, persisted app state. One shared instance drives the sidebar,
/// the Control Center, and the full Settings tab so every surface stays
/// in sync.
final class BrowserSettings: ObservableObject {
    static let shared = BrowserSettings()

    @Published var appearance: AppAppearance {
        didSet { UserDefaults.standard.set(appearance.rawValue, forKey: "appearance") }
    }
    @Published var accentColor: Color {
        didSet { UserDefaults.standard.set(accentColor.toHex(), forKey: "accentColor") }
    }
    @Published var sidebarAnimationsEnabled: Bool {
        didSet { UserDefaults.standard.set(sidebarAnimationsEnabled, forKey: "sidebarAnimationsEnabled") }
    }
    @Published var glassIntensity: Double {
        didSet { UserDefaults.standard.set(glassIntensity, forKey: "glassIntensity") }
    }
    @Published var sidebarOnRight: Bool {
        didSet { UserDefaults.standard.set(sidebarOnRight, forKey: "sidebarOnRight") }
    }
    /// Remembered so the sidebar reopens the way you left it.
    @Published var sidebarCollapsed: Bool {
        didSet { UserDefaults.standard.set(sidebarCollapsed, forKey: "sidebarCollapsed") }
    }

    // MARK: Browsing / search
    @Published var searchEngine: SearchEngine {
        didSet { UserDefaults.standard.set(searchEngine.rawValue, forKey: "searchEngine") }
    }
    @Published var homePage: String {
        didSet { UserDefaults.standard.set(homePage, forKey: "homePage") }
    }

    // MARK: Privacy
    @Published var blockTrackers: Bool {
        didSet { UserDefaults.standard.set(blockTrackers, forKey: "blockTrackers") }
    }
    @Published var sendDoNotTrack: Bool {
        didSet { UserDefaults.standard.set(sendDoNotTrack, forKey: "sendDoNotTrack") }
    }
    @Published var blockPopups: Bool {
        didSet { UserDefaults.standard.set(blockPopups, forKey: "blockPopups") }
    }
    @Published var clearCookiesOnQuit: Bool {
        didSet { UserDefaults.standard.set(clearCookiesOnQuit, forKey: "clearCookiesOnQuit") }
    }

    // MARK: Local AI
    @Published var localAIEndpoint: String {
        didSet { UserDefaults.standard.set(localAIEndpoint, forKey: "localAIEndpoint") }
    }
    @Published var localAIEnabled: Bool {
        didSet { UserDefaults.standard.set(localAIEnabled, forKey: "localAIEnabled") }
    }
    @Published var allowAIToControlPages: Bool {
        didSet { UserDefaults.standard.set(allowAIToControlPages, forKey: "allowAIToControlPages") }
    }

    private init() {
        let d = UserDefaults.standard
        appearance = AppAppearance(rawValue: d.string(forKey: "appearance") ?? "system") ?? .system
        accentColor = Color(hex: d.string(forKey: "accentColor") ?? "#6C8CFF")
        sidebarAnimationsEnabled = d.object(forKey: "sidebarAnimationsEnabled") as? Bool ?? true
        glassIntensity = d.object(forKey: "glassIntensity") as? Double ?? 0.6
        sidebarOnRight = d.object(forKey: "sidebarOnRight") as? Bool ?? false
        sidebarCollapsed = d.object(forKey: "sidebarCollapsed") as? Bool ?? false

        // Defaults to DuckDuckGo, remembered from then on.
        searchEngine = SearchEngine(rawValue: d.string(forKey: "searchEngine") ?? SearchEngine.duckduckgo.rawValue) ?? .duckduckgo
        homePage = d.string(forKey: "homePage") ?? "https://duckduckgo.com"

        blockTrackers = d.object(forKey: "blockTrackers") as? Bool ?? true
        sendDoNotTrack = d.object(forKey: "sendDoNotTrack") as? Bool ?? true
        blockPopups = d.object(forKey: "blockPopups") as? Bool ?? true
        clearCookiesOnQuit = d.object(forKey: "clearCookiesOnQuit") as? Bool ?? false

        localAIEndpoint = d.string(forKey: "localAIEndpoint") ?? "http://localhost:11434"
        localAIEnabled = d.object(forKey: "localAIEnabled") as? Bool ?? false
        allowAIToControlPages = d.object(forKey: "allowAIToControlPages") as? Bool ?? false
    }
}

extension Color {
    init(hex: String) {
        var s = hex.trimmingCharacters(in: .whitespacesAndNewlines)
        s.removeAll { $0 == "#" }
        var rgb: UInt64 = 0
        Scanner(string: s).scanHexInt64(&rgb)
        let r = Double((rgb >> 16) & 0xFF) / 255
        let g = Double((rgb >> 8) & 0xFF) / 255
        let b = Double(rgb & 0xFF) / 255
        self.init(red: r, green: g, blue: b)
    }
    func toHex() -> String {
        guard let c = NSColor(self).usingColorSpace(.deviceRGB) else { return "#6C8CFF" }
        let r = Int(c.redComponent * 255), g = Int(c.greenComponent * 255), b = Int(c.blueComponent * 255)
        return String(format: "#%02X%02X%02X", r, g, b)
    }
}
