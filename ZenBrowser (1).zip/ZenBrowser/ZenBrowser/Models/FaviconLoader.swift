import AppKit
import WebKit

/// Fetches each tab's real favicon so the sidebar (expanded or collapsed)
/// shows the site's own icon instead of a generic globe.
final class FaviconLoader {
    static let shared = FaviconLoader()
    private var cache: [String: NSImage] = [:]

    func loadFavicon(for tab: BrowserTab) {
        let js = "document.querySelector(\"link[rel~='icon']\")?.href || (location.origin + '/favicon.ico')"
        tab.webView.evaluateJavaScript(js) { [weak self] result, _ in
            guard let self, let href = result as? String, let url = URL(string: href) else { return }
            if let cached = self.cache[href] {
                DispatchQueue.main.async { tab.favicon = cached }
                return
            }
            URLSession.shared.dataTask(with: url) { data, _, _ in
                guard let data, let image = NSImage(data: data) else { return }
                self.cache[href] = image
                DispatchQueue.main.async { tab.favicon = image }
            }.resume()
        }
    }
}
