import Foundation
import Combine
import WebKit
import AppKit

final class BrowserTab: ObservableObject, Identifiable, Equatable {
    let id = UUID()
    @Published var title: String = "New Tab"
    @Published var urlString: String
    @Published var isPlayingAudio: Bool = false
    @Published var isMuted: Bool = false
    @Published var volume: Double = 1.0
    @Published var isLoading: Bool = false
    @Published var faviconSystemName: String = "globe"
    @Published var favicon: NSImage?

    let webView: WKWebView

    init(urlString: String = "https://www.apple.com") {
        self.urlString = urlString
        let config = WKWebViewConfiguration()
        config.mediaTypesRequiringUserActionForPlayback = []
        self.webView = WKWebView(frame: .zero, configuration: config)
        load(urlString)
    }

    func load(_ urlString: String) {
        self.urlString = urlString
        guard let url = URL(string: urlString.hasPrefix("http") ? urlString : "https://\(urlString)") else { return }
        webView.load(URLRequest(url: url))
    }

    static func == (lhs: BrowserTab, rhs: BrowserTab) -> Bool { lhs.id == rhs.id }
}
