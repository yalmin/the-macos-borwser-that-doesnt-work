import Foundation
import WebKit

/// Bridges a locally running model (Ollama, LM Studio, or anything
/// exposing an OpenAI/Ollama-style HTTP API on localhost) to the active
/// web page, so the model can read the page and act on it — click links,
/// fill fields, scroll — like a lightweight browser agent.
///
/// This is a working skeleton: `requestNextAction` + `perform` form the
/// full loop, but you'll likely want to adapt `callModel`'s request body
/// to whatever local server you run (Ollama's /api/generate shape is
/// used here as a default).
final class LocalAIController: ObservableObject {
    @Published var isConnected = false
    @Published var lastError: String?

    func testConnection(endpoint: String, completion: @escaping (Bool) -> Void) {
        guard let url = URL(string: endpoint) else { completion(false); return }
        var request = URLRequest(url: url)
        request.timeoutInterval = 4
        URLSession.shared.dataTask(with: request) { _, response, error in
            DispatchQueue.main.async {
                if let http = response as? HTTPURLResponse, error == nil {
                    self.isConnected = (200..<500).contains(http.statusCode)
                    completion(self.isConnected)
                } else {
                    self.isConnected = false
                    self.lastError = error?.localizedDescription
                    completion(false)
                }
            }
        }.resume()
    }

    /// Pulls a simplified snapshot of interactive elements on the page and
    /// asks the local model what to do next toward `goal`.
    func requestNextAction(for tab: BrowserTab, endpoint: String, goal: String, completion: @escaping (PageAction?) -> Void) {
        let snapshotJS = """
        (function() {
            const els = Array.from(document.querySelectorAll('a, button, input, textarea, select'))
                .slice(0, 200)
                .map((el, i) => {
                    el.setAttribute('data-zen-id', i);
                    return `${i}: <${el.tagName.toLowerCase()}> ${(el.innerText||el.value||el.placeholder||'').slice(0,60)}`;
                });
            return JSON.stringify({ title: document.title, url: location.href, elements: els });
        })();
        """
        tab.webView.evaluateJavaScript(snapshotJS) { result, _ in
            guard let jsonString = result as? String, let payload = jsonString.data(using: .utf8) else {
                completion(nil); return
            }
            self.callModel(endpoint: endpoint, goal: goal, pageJSON: payload, completion: completion)
        }
    }

    private func callModel(endpoint: String, goal: String, pageJSON: Data, completion: @escaping (PageAction?) -> Void) {
        guard let url = URL(string: endpoint.appending("/api/generate")) else { completion(nil); return }
        let pageText = String(data: pageJSON, encoding: .utf8) ?? "{}"
        let prompt = """
        You control a web page for the user. Goal: \(goal)
        Page snapshot: \(pageText)
        Reply ONLY with JSON: {"action":"click|type|scroll|done","targetId":<int|null>,"text":<string|null>}
        """
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try? JSONSerialization.data(withJSONObject: [
            "model": "llama3", "prompt": prompt, "stream": false
        ])
        URLSession.shared.dataTask(with: request) { data, _, _ in
            guard let data,
                  let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let text = obj["response"] as? String,
                  let actionData = text.data(using: .utf8),
                  let action = try? JSONDecoder().decode(PageAction.self, from: actionData) else {
                completion(nil); return
            }
            completion(action)
        }.resume()
    }

    func perform(_ action: PageAction, on tab: BrowserTab) {
        guard let id = action.targetId else { return }
        switch action.action {
        case "click":
            tab.webView.evaluateJavaScript("document.querySelector('[data-zen-id=\"\(id)\"]')?.click();")
        case "type":
            let text = (action.text ?? "").replacingOccurrences(of: "'", with: "\\'")
            tab.webView.evaluateJavaScript("""
            const el = document.querySelector('[data-zen-id="\(id)"]');
            if (el) { el.value = '\(text)'; el.dispatchEvent(new Event('input', { bubbles: true })); }
            """)
        case "scroll":
            tab.webView.evaluateJavaScript("document.querySelector('[data-zen-id=\"\(id)\"]')?.scrollIntoView({behavior:'smooth'});")
        default: break
        }
    }
}

struct PageAction: Codable {
    let action: String
    let targetId: Int?
    let text: String?
}
