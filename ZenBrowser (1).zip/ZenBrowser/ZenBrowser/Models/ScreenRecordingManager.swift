import Foundation
import ScreenCaptureKit
import AVFoundation
import AppKit

/// Records the main display to a .mov file using ScreenCaptureKit, muxed
/// through AVAssetWriter. The first time this runs, macOS will prompt for
/// Screen Recording permission (System Settings > Privacy & Security);
/// after that it starts immediately.
@available(macOS 13.0, *)
final class ScreenRecordingManager: NSObject, ObservableObject, SCStreamOutput {
    static let shared = ScreenRecordingManager()

    @Published var isRecording = false

    private var stream: SCStream?
    private var writer: AVAssetWriter?
    private var input: AVAssetWriterInput?
    private var sessionStarted = false
    private var outputURL: URL?

    func toggle() {
        isRecording ? stop() : start()
    }

    private func start() {
        Task {
            do {
                let content = try await SCShareableContent.excludingDesktopWindows(false, onScreenWindowsOnly: true)
                guard let display = content.displays.first else { return }

                let filter = SCContentFilter(display: display, excludingWindows: [])
                let config = SCStreamConfiguration()
                config.width = display.width
                config.height = display.height
                config.minimumFrameInterval = CMTime(value: 1, timescale: 30)
                config.pixelFormat = kCVPixelFormatType_32BGRA
                config.showsCursor = true

                let desktop = FileManager.default.urls(for: .desktopDirectory, in: .userDomainMask).first
                    ?? FileManager.default.homeDirectoryForCurrentUser
                let formatter = DateFormatter()
                formatter.dateFormat = "yyyy-MM-dd 'at' HH.mm.ss"
                let url = desktop.appendingPathComponent("ZenBrowser Recording \(formatter.string(from: Date())).mov")
                outputURL = url
                try? FileManager.default.removeItem(at: url)

                let writer = try AVAssetWriter(outputURL: url, fileType: .mov)
                let outputSettings: [String: Any] = [
                    AVVideoCodecKey: AVVideoCodecType.h264,
                    AVVideoWidthKey: display.width,
                    AVVideoHeightKey: display.height
                ]
                let input = AVAssetWriterInput(mediaType: .video, outputSettings: outputSettings)
                input.expectsMediaDataInRealTime = true
                writer.add(input)
                self.writer = writer
                self.input = input
                self.sessionStarted = false

                let stream = SCStream(filter: filter, configuration: config, delegate: nil)
                try stream.addStreamOutput(self, type: .screen, sampleHandlerQueue: DispatchQueue(label: "zen.screenrecording"))
                try await stream.startCapture()
                self.stream = stream

                await MainActor.run { self.isRecording = true }
            } catch {
                print("Screen recording failed to start: \(error)")
            }
        }
    }

    private func stop() {
        Task {
            try? await stream?.stopCapture()
            input?.markAsFinished()
            await writer?.finishWriting()
            stream = nil
            let url = outputURL
            await MainActor.run {
                self.isRecording = false
                if let url { NSWorkspace.shared.activateFileViewerSelecting([url]) }
            }
        }
    }

    func stream(_ stream: SCStream, didOutputSampleBuffer sampleBuffer: CMSampleBuffer, of type: SCStreamOutputType) {
        guard type == .screen, let writer, let input, CMSampleBufferDataIsReady(sampleBuffer) else { return }
        if !sessionStarted {
            writer.startWriting()
            writer.startSession(atSourceTime: CMSampleBufferGetPresentationTimeStamp(sampleBuffer))
            sessionStarted = true
        }
        if input.isReadyForMoreMediaData {
            input.append(sampleBuffer)
        }
    }
}
