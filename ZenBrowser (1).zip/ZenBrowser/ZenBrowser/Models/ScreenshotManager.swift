import AppKit
import WebKit

/// Captures the active page and saves it as a PNG to the Desktop, and
/// also puts it on the clipboard — this is a real, working capture using
/// WKWebView's own snapshot API (no extra permissions required).
final class ScreenshotManager {
    static let shared = ScreenshotManager()

    func capture(tab: BrowserTab) {
        let config = WKSnapshotConfiguration()
        tab.webView.takeSnapshot(with: config) { image, _ in
            guard let image else { return }
            self.save(image)
        }
    }

    private func save(_ image: NSImage) {
        guard let tiff = image.tiffRepresentation,
              let rep = NSBitmapImageRep(data: tiff),
              let png = rep.representation(using: .png, properties: [:]) else { return }

        let desktop = FileManager.default.urls(for: .desktopDirectory, in: .userDomainMask).first
            ?? FileManager.default.homeDirectoryForCurrentUser
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd 'at' HH.mm.ss"
        let url = desktop.appendingPathComponent("ZenBrowser Screenshot \(formatter.string(from: Date())).png")
        try? png.write(to: url)

        NSPasteboard.general.clearContents()
        NSPasteboard.general.setData(png, forType: .png)
        NSWorkspace.shared.activateFileViewerSelecting([url])
    }
}
