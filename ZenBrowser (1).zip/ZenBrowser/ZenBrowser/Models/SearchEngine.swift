import Foundation

/// The engine used by the sidebar's search/address bar. Defaults to
/// DuckDuckGo and is persisted in BrowserSettings, so the choice sticks.
enum SearchEngine: String, CaseIterable, Identifiable {
    case duckduckgo, google, bing, brave, ecosia

    var id: String { rawValue }

    var displayName: String {
        switch self {
        case .duckduckgo: return "DuckDuckGo"
        case .google: return "Google"
        case .bing: return "Bing"
        case .brave: return "Brave Search"
        case .ecosia: return "Ecosia"
        }
    }

    var searchURLTemplate: String {
        switch self {
        case .duckduckgo: return "https://duckduckgo.com/?q="
        case .google: return "https://www.google.com/search?q="
        case .bing: return "https://www.bing.com/search?q="
        case .brave: return "https://search.brave.com/search?q="
        case .ecosia: return "https://www.ecosia.org/search?q="
        }
    }

    /// Turns whatever was typed in the search/address bar into a URL:
    /// something that looks like a real address is loaded directly,
    /// anything else is run through the chosen search engine.
    func resolve(_ input: String) -> URL? {
        let trimmed = input.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return nil }

        let looksLikeURL = trimmed.contains(".") && !trimmed.contains(" ")
        if looksLikeURL {
            let withScheme = (trimmed.hasPrefix("http://") || trimmed.hasPrefix("https://")) ? trimmed : "https://\(trimmed)"
            if let url = URL(string: withScheme) { return url }
        }
        let query = trimmed.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? trimmed
        return URL(string: searchURLTemplate + query)
    }
}
