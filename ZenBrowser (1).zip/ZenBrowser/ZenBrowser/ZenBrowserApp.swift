import SwiftUI

@main
struct ZenBrowserApp: App {
    var body: some Scene {
        WindowGroup {
            BrowserWindowView()
                .frame(minWidth: 1000, minHeight: 640)
        }
        .windowStyle(.hiddenTitleBar)
        .windowToolbarStyle(.unifiedCompact)
    }
}
