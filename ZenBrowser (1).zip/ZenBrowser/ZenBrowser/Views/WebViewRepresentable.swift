import SwiftUI
import WebKit

struct WebViewRepresentable: NSViewRepresentable {
    @ObservedObject var tab: BrowserTab

    func makeNSView(context: Context) -> WKWebView {
        tab.webView.navigationDelegate = context.coordinator
        tab.webView.uiDelegate = context.coordinator
        tab.webView.allowsMagnification = true
        injectMediaWatcher()
        return tab.webView
    }

    func updateNSView(_ nsView: WKWebView, context: Context) {}

    func makeCoordinator() -> Coordinator { Coordinator(tab: tab) }

    /// Watches HTML5 media elements so the sidebar can show a "playing
    /// audio" indicator and the Volume Mixer can control real page volume.
    private func injectMediaWatcher() {
        let js = """
        (function() {
            function watch() {
                document.querySelectorAll('video,audio').forEach(el => {
                    if (el.dataset.zenWatched) return;
                    el.dataset.zenWatched = '1';
                    const notify = () => window.webkit?.messageHandlers?.zenMedia?.postMessage({
                        playing: !el.paused && !el.ended
                    });
                    el.addEventListener('play', notify);
                    el.addEventListener('pause', notify);
                    el.addEventListener('volumechange', notify);
                });
            }
            new MutationObserver(watch).observe(document.body || document.documentElement, { childList: true, subtree: true });
            watch();
        })();
        """
        let script = WKUserScript(source: js, injectionTime: .atDocumentEnd, forMainFrameOnly: false)
        tab.webView.configuration.userContentController.addUserScript(script)
        tab.webView.configuration.userContentController.add(MediaMessageHandler(tab: tab), name: "zenMedia")
    }

    final class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate {
        let tab: BrowserTab
        init(tab: BrowserTab) { self.tab = tab }
        func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
            tab.isLoading = true
        }
        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            tab.isLoading = false
            tab.title = webView.title?.isEmpty == false ? webView.title! : tab.urlString
            FaviconLoader.shared.loadFavicon(for: tab)
        }
    }
}

final class MediaMessageHandler: NSObject, WKScriptMessageHandler {
    let tab: BrowserTab
    init(tab: BrowserTab) { self.tab = tab }
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        if let dict = message.body as? [String: Any], let playing = dict["playing"] as? Bool {
            DispatchQueue.main.async { self.tab.isPlayingAudio = playing }
        }
    }
}
