import SwiftUI

struct SettingsTabView: View {
    @ObservedObject var settings: BrowserSettings
    @State private var section = "General"
    let sections = ["General", "Appearance", "Privacy", "Local AI", "Extensions", "Shortcuts"]

    var body: some View {
        ZStack {
            // Liquid-glass backdrop for the whole Settings tab, matching
            // the Control Center's look.
            GlassBackground(material: .underWindowBackground, cornerRadius: 0, intensity: settings.glassIntensity)
                .ignoresSafeArea()

            HStack(spacing: 0) {
                List(sections, id: \.self, selection: $section) { s in
                    Text(s).tag(s)
                }
                .listStyle(.sidebar)
                .scrollContentBackground(.hidden)
                .frame(width: 190)

                Divider().opacity(0.2)

                ScrollView {
                    VStack(alignment: .leading, spacing: 20) {
                        switch section {
                        case "Appearance": CustomizationPanel(settings: settings)
                        case "Local AI": LocalAIPanel(settings: settings)
                        case "Extensions": ExtensionsPanel()
                        case "Privacy": privacySection
                        case "Shortcuts": shortcutsSection
                        default: generalSection
                        }
                    }
                    .padding(28)
                    .frame(maxWidth: 560, alignment: .leading)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
    }

    // MARK: General
    private var generalSection: some View {
        VStack(alignment: .leading, spacing: 18) {
            Text("General").font(.title2.bold())

            SettingsCard(title: "Search engine") {
                Picker("Search engine", selection: $settings.searchEngine) {
                    ForEach(SearchEngine.allCases) { engine in
                        Text(engine.displayName).tag(engine)
                    }
                }
                .labelsHidden()
                .pickerStyle(.menu)
                Text("Used by the sidebar's search bar. Defaults to DuckDuckGo.")
                    .font(.system(size: 10.5)).opacity(0.55)
            }

            SettingsCard(title: "Home page") {
                TextField("https://duckduckgo.com", text: $settings.homePage)
                    .textFieldStyle(.roundedBorder)
            }

            SettingsCard(title: "Tabs") {
                Toggle("Open new tabs next to current tab", isOn: .constant(true))
                Toggle("Show favicons", isOn: .constant(true))
            }
        }
    }

    // MARK: Privacy
    private var privacySection: some View {
        VStack(alignment: .leading, spacing: 18) {
            Text("Privacy").font(.title2.bold())

            SettingsCard(title: "Tracking") {
                Toggle("Block known trackers", isOn: $settings.blockTrackers)
                Toggle("Send \u{201C}Do Not Track\u{201D} requests", isOn: $settings.sendDoNotTrack)
                Toggle("Block pop-ups", isOn: $settings.blockPopups)
            }

            SettingsCard(title: "Cookies & site data") {
                Toggle("Clear cookies when the browser quits", isOn: $settings.clearCookiesOnQuit)
                Button("Clear All Website Data Now") { WebsiteDataCleaner.clearAll() }
                    .buttonStyle(GlassButtonStyle(tint: settings.accentColor))
                    .frame(width: 220)
            }
        }
    }

    private var shortcutsSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Shortcuts").font(.title2.bold())
            SettingsCard(title: "Keyboard") {
                Text("Keyboard shortcut customization goes here.")
                    .font(.system(size: 11.5)).opacity(0.6)
            }
        }
    }
}

/// A small translucent card used to group related settings, keeping the
/// whole Settings tab visually consistent with the liquid-glass Control
/// Center.
private struct SettingsCard<Content: View>: View {
    let title: String
    @ViewBuilder var content: Content

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(title).font(.system(size: 12, weight: .semibold)).opacity(0.6)
            content
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(.white.opacity(0.12), lineWidth: 1))
    }
}
