import SwiftUI

struct VolumeMixerPanel: View {
    @Binding var tabs: [BrowserTab]
    var playingTabs: [BrowserTab] { tabs.filter { $0.isPlayingAudio } }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            if playingTabs.isEmpty {
                Text("No tabs are currently playing audio.")
                    .font(.system(size: 11.5)).opacity(0.6)
            } else {
                ForEach(playingTabs) { tab in
                    VStack(alignment: .leading, spacing: 4) {
                        HStack {
                            Text(tab.title).font(.system(size: 11.5)).lineLimit(1)
                            Spacer()
                            Button {
                                tab.isMuted.toggle()
                                tab.webView.evaluateJavaScript("document.querySelectorAll('video,audio').forEach(m=>m.muted=\(tab.isMuted));")
                            } label: {
                                Image(systemName: tab.isMuted ? "speaker.slash.fill" : "speaker.wave.2.fill")
                            }.buttonStyle(.plain)
                        }
                        Slider(value: Binding(get: { tab.volume }, set: { newVal in
                            tab.volume = newVal
                            tab.webView.evaluateJavaScript("document.querySelectorAll('video,audio').forEach(m=>m.volume=\(newVal));")
                        }), in: 0...1)
                    }
                }
            }
        }
    }
}
