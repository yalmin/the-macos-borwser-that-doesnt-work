import SwiftUI
import WebKit

struct ControlCenterHome: View {
    @ObservedObject var settings: BrowserSettings
    @Binding var tabs: [BrowserTab]
    var activeTab: BrowserTab?
    var navigate: (ControlCenterPage) -> Void

    @StateObject private var recorder = ScreenRecordingManager.shared
    @State private var focusMode = false
    @State private var readerMode = false

    let columns = [GridItem(.flexible()), GridItem(.flexible())]

    var body: some View {
        ScrollView {
            LazyVGrid(columns: columns, spacing: 10) {
                // --- Simple one-tap toggles ---
                simpleToggle(icon: settings.appearance == .dark ? "moon.fill" : "sun.max.fill",
                             label: settings.appearance == .dark ? "Dark" : "Light") {
                    withAnimation(.easeInOut(duration: 0.4)) {
                        settings.appearance = settings.appearance == .dark ? .light : .dark
                    }
                }
                simpleToggle(icon: recorder.isRecording ? "record.circle.fill" : "record.circle",
                             label: recorder.isRecording ? "Recording…" : "Screen Record",
                             tint: recorder.isRecording ? .red : .primary) {
                    recorder.toggle()
                }
                simpleToggle(icon: focusMode ? "moon.stars.fill" : "moon.stars", label: "Focus Mode") {
                    focusMode.toggle()
                }
                simpleToggle(icon: "doc.text.magnifyingglass", label: "Reader Mode") {
                    readerMode.toggle()
                    activeTab?.webView.evaluateJavaScript("document.body.style.maxWidth = document.body.style.maxWidth ? '' : '680px'; document.body.style.margin = document.body.style.margin ? '' : '0 auto';")
                }
                simpleToggle(icon: "pip.fill", label: "Picture in Picture") {
                    activeTab?.webView.evaluateJavaScript("document.querySelector('video')?.requestPictureInPicture?.();")
                }
                simpleToggle(icon: "speaker.slash.fill", label: "Mute All") {
                    tabs.forEach { $0.isMuted = true }
                }
                simpleToggle(icon: "camera.viewfinder", label: "Screenshot") {
                    if let tab = activeTab { ScreenshotManager.shared.capture(tab: tab) }
                }
                simpleToggle(icon: "trash", label: "Clear Cookies") {
                    WebsiteDataCleaner.clearAll()
                }

                // --- Complex buttons: open a sub-page inside this same panel ---
                navButton(icon: "cpu", label: "Local AI", page: .localAI, badge: settings.localAIEnabled ? "On" : nil)
                navButton(icon: "paintpalette.fill", label: "Customize", page: .customization)
                navButton(icon: "slider.horizontal.3", label: "Volume Mixer", page: .volumeMixer)
                navButton(icon: "puzzlepiece.extension.fill", label: "Extensions", page: .extensions)
            }

            Button {
                NotificationCenter.default.post(name: .openSettingsTab, object: nil)
            } label: {
                Label("Open Full Settings", systemImage: "gearshape.fill").frame(maxWidth: .infinity)
            }
            .buttonStyle(GlassButtonStyle(tint: settings.accentColor))
            .padding(.top, 10)
        }
    }

    private func simpleToggle(icon: String, label: String, tint: Color = .primary, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(spacing: 6) {
                Image(systemName: icon).font(.system(size: 18)).foregroundStyle(tint)
                Text(label).font(.system(size: 10.5))
            }
        }
        .buttonStyle(GlassButtonStyle(tint: settings.accentColor))
    }

    private func navButton(icon: String, label: String, page: ControlCenterPage, badge: String? = nil) -> some View {
        Button {
            withAnimation(.spring(response: 0.3, dampingFraction: 0.85)) { navigate(page) }
        } label: {
            VStack(spacing: 6) {
                ZStack(alignment: .topTrailing) {
                    Image(systemName: icon).font(.system(size: 18))
                    if let badge {
                        Text(badge).font(.system(size: 8, weight: .bold))
                            .padding(.horizontal, 4).padding(.vertical, 1)
                            .background(Color.green, in: Capsule())
                            .offset(x: 12, y: -6)
                    }
                }
                Text(label).font(.system(size: 10.5))
            }
        }
        .buttonStyle(GlassButtonStyle(tint: settings.accentColor))
    }
}

extension Notification.Name {
    static let openSettingsTab = Notification.Name("openSettingsTab")
}

enum WebsiteDataCleaner {
    static func clearAll() {
        let types = WKWebsiteDataStore.allWebsiteDataTypes()
        WKWebsiteDataStore.default().removeData(ofTypes: types, modifiedSince: .distantPast) {}
    }
}
