import SwiftUI

struct CustomizationPanel: View {
    @ObservedObject var settings: BrowserSettings

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            ColorPicker("Accent color", selection: $settings.accentColor)
            Toggle("Sidebar animations", isOn: $settings.sidebarAnimationsEnabled)
            Toggle("Sidebar on right", isOn: $settings.sidebarOnRight)

            VStack(alignment: .leading, spacing: 6) {
                Text("Glass intensity").font(.caption).opacity(0.6)
                Slider(value: $settings.glassIntensity, in: 0...1)
            }

            Picker("Theme", selection: $settings.appearance) {
                Text("System").tag(AppAppearance.system)
                Text("Light").tag(AppAppearance.light)
                Text("Dark").tag(AppAppearance.dark)
            }
            .pickerStyle(.segmented)
        }
    }
}
