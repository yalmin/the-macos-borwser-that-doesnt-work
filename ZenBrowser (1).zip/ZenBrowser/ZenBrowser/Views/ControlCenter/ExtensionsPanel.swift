import SwiftUI

struct ExtensionEntry: Identifiable {
    let id = UUID()
    let name: String
    let icon: String
    var enabled: Bool
}

struct ExtensionsPanel: View {
    @State private var extensions: [ExtensionEntry] = [
        .init(name: "Ad Blocker", icon: "shield.lefthalf.filled", enabled: true),
        .init(name: "Password Manager", icon: "key.fill", enabled: true),
        .init(name: "Dark Reader", icon: "circle.lefthalf.filled", enabled: false),
        .init(name: "Translate", icon: "character.bubble", enabled: false)
    ]
    @State private var configuring: ExtensionEntry?

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            ForEach($extensions) { $ext in
                HStack {
                    Image(systemName: ext.icon)
                    Text(ext.name).font(.system(size: 12))
                    Spacer()
                    Button("Configure") { configuring = ext }
                        .buttonStyle(.plain).font(.system(size: 10.5)).opacity(0.6)
                    Toggle("", isOn: $ext.enabled).toggleStyle(.switch).labelsHidden()
                }
            }
        }
        .sheet(item: $configuring) { ext in
            VStack(spacing: 16) {
                Text("\(ext.name) settings").font(.headline)
                Text("Extension-specific configuration would render here.")
                    .font(.caption).opacity(0.6)
                Button("Done") { configuring = nil }
            }
            .padding(24).frame(width: 320, height: 180)
        }
    }
}
