import SwiftUI

enum ControlCenterPage {
    case home, localAI, customization, volumeMixer, extensions
}

struct ControlCenterOverlay: View {
    @ObservedObject var settings: BrowserSettings
    @Binding var tabs: [BrowserTab]
    var activeTab: BrowserTab?
    @State private var page: ControlCenterPage = .home

    var body: some View {
        GeometryReader { geo in
            VStack(alignment: .leading, spacing: 14) {
                header
                Divider().opacity(0.2)
                Group {
                    switch page {
                    case .home:
                        ControlCenterHome(settings: settings, tabs: $tabs, activeTab: activeTab, navigate: { page = $0 })
                    case .localAI:
                        LocalAIPanel(settings: settings)
                    case .customization:
                        CustomizationPanel(settings: settings)
                    case .volumeMixer:
                        VolumeMixerPanel(tabs: $tabs)
                    case .extensions:
                        ExtensionsPanel()
                    }
                }
                Spacer(minLength: 0)
            }
            .padding(18)
            .frame(width: max(280, geo.size.width * 0.26), height: max(320, geo.size.height * 0.55))
            .background(GlassBackground(cornerRadius: 26, intensity: settings.glassIntensity))
            .clipShape(RoundedRectangle(cornerRadius: 26))
            .overlay(RoundedRectangle(cornerRadius: 26).stroke(.white.opacity(0.15), lineWidth: 1))
            .shadow(color: .black.opacity(0.35), radius: 30, y: 10)
            .padding(.top, 14).padding(.leading, 14)
            .transition(.asymmetric(insertion: .scale(scale: 0.85, anchor: .topLeading).combined(with: .opacity),
                                     removal: .opacity))
        }
    }

    private var header: some View {
        HStack {
            if page != .home {
                Button {
                    withAnimation(.spring(response: 0.3, dampingFraction: 0.85)) { page = .home }
                } label: { Image(systemName: "chevron.left") }
                .buttonStyle(.plain)
            }
            Text(title).font(.system(size: 13, weight: .semibold)).opacity(0.8)
            Spacer()
        }
    }

    private var title: String {
        switch page {
        case .home: return "Control Center"
        case .localAI: return "Local AI"
        case .customization: return "Customize"
        case .volumeMixer: return "Volume Mixer"
        case .extensions: return "Extensions"
        }
    }
}
