import SwiftUI
import AppKit

/// "Liquid glass" backdrop used by the Control Center: a real vibrancy
/// blur (NSVisualEffectView) with rounded corners, so it reads as
/// translucent frosted glass rather than a flat sheet.
struct GlassBackground: NSViewRepresentable {
    var material: NSVisualEffectView.Material = .hudWindow
    var cornerRadius: CGFloat = 24
    /// 0 = very see-through liquid glass, 1 = denser/frostier. Driven by
    /// the Customize panel's "Glass intensity" slider.
    var intensity: Double = 0.6

    func makeNSView(context: Context) -> NSVisualEffectView {
        let v = NSVisualEffectView()
        v.material = material
        v.blendingMode = .behindWindow
        v.state = .active
        v.wantsLayer = true
        v.layer?.cornerRadius = cornerRadius
        v.layer?.masksToBounds = true
        v.alphaValue = 0.5 + (intensity * 0.5)
        return v
    }
    func updateNSView(_ nsView: NSVisualEffectView, context: Context) {
        nsView.layer?.cornerRadius = cornerRadius
        nsView.alphaValue = 0.5 + (intensity * 0.5)
    }
}

/// Glassy pill/tile buttons used throughout the Control Center.
struct GlassButtonStyle: ButtonStyle {
    var tint: Color = .white
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .padding(.vertical, 10)
            .frame(maxWidth: .infinity)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 14))
            .overlay(
                RoundedRectangle(cornerRadius: 14)
                    .stroke(tint.opacity(configuration.isPressed ? 0.6 : 0.25), lineWidth: 1)
            )
            .scaleEffect(configuration.isPressed ? 0.96 : 1)
            .animation(.easeOut(duration: 0.15), value: configuration.isPressed)
    }
}
