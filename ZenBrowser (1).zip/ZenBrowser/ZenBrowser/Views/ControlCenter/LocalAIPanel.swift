import SwiftUI

struct LocalAIPanel: View {
    @ObservedObject var settings: BrowserSettings
    @StateObject private var controller = LocalAIController()
    @State private var isTesting = false

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Toggle("Enable Local AI", isOn: $settings.localAIEnabled)
                .toggleStyle(.switch)

            VStack(alignment: .leading, spacing: 6) {
                Text("Local endpoint").font(.caption).opacity(0.6)
                TextField("http://localhost:11434", text: $settings.localAIEndpoint)
                    .textFieldStyle(.roundedBorder)
            }

            Toggle("Allow AI to control web pages", isOn: $settings.allowAIToControlPages)
                .toggleStyle(.switch)
            Text("When on, the model can click, type, and scroll on the page you're viewing to complete tasks you ask it to do.")
                .font(.system(size: 10.5)).opacity(0.55)

            HStack {
                Circle().fill(controller.isConnected ? Color.green : Color.gray).frame(width: 8, height: 8)
                Text(controller.isConnected ? "Connected" : "Not connected").font(.caption)
                Spacer()
                Button(isTesting ? "Testing…" : "Test Connection") {
                    isTesting = true
                    controller.testConnection(endpoint: settings.localAIEndpoint) { _ in isTesting = false }
                }
                .buttonStyle(GlassButtonStyle())
                .frame(width: 130)
            }
        }
    }
}
