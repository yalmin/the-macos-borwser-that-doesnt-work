import SwiftUI

struct SidebarView: View {
    @ObservedObject var settings: BrowserSettings
    @Binding var tabs: [BrowserTab]
    @Binding var selectedTabID: UUID?

    @State private var addressText: String = ""

    private var collapsed: Bool { settings.sidebarCollapsed }

    var body: some View {
        VStack(spacing: 8) {
            header
            if !collapsed {
                searchBar
            }
            ScrollView {
                VStack(spacing: 4) {
                    ForEach(tabs) { tab in
                        TabRow(tab: tab, isSelected: tab.id == selectedTabID, collapsed: collapsed)
                            .onTapGesture { selectedTabID = tab.id }
                            .contextMenu {
                                Button("Close Tab") { close(tab) }
                                Button(tab.isMuted ? "Unmute" : "Mute") { tab.isMuted.toggle() }
                            }
                    }
                }
                .padding(.horizontal, collapsed ? 6 : 8)
            }
            Spacer(minLength: 0)
            if collapsed {
                Button(action: newTab) { Image(systemName: "plus.circle.fill") }
                    .buttonStyle(.plain)
                    .padding(.bottom, 12)
            }
        }
        .frame(width: collapsed ? 64 : 220)
        .background(.ultraThinMaterial)
        .animation(settings.sidebarAnimationsEnabled ? .spring(response: 0.35, dampingFraction: 0.82) : nil, value: collapsed)
        .animation(settings.sidebarAnimationsEnabled ? .spring(response: 0.35, dampingFraction: 0.8) : nil, value: tabs.count)
        .onChange(of: selectedTabID) { _ in syncAddressBar() }
        .onAppear { syncAddressBar() }
    }

    private var header: some View {
        HStack {
            if !collapsed {
                Text("ZEN").font(.system(size: 13, weight: .bold)).opacity(0.6)
                Spacer()
            }
            // Zen-style collapse toggle for the whole sidebar.
            Button {
                withAnimation { settings.sidebarCollapsed.toggle() }
            } label: {
                Image(systemName: "sidebar.leading")
                    .rotationEffect(.degrees(collapsed ? 180 : 0))
            }
            .buttonStyle(.plain)

            if !collapsed {
                Button(action: newTab) { Image(systemName: "plus.circle.fill") }.buttonStyle(.plain)
            }
        }
        .padding(.horizontal, collapsed ? 0 : 12)
        .padding(.top, 12)
        .frame(maxWidth: .infinity)
    }

    private var searchBar: some View {
        HStack(spacing: 6) {
            Image(systemName: "magnifyingglass").font(.system(size: 11)).opacity(0.5)
            TextField("Search \(settings.searchEngine.displayName) or enter address", text: $addressText, onCommit: submit)
                .textFieldStyle(.plain)
                .font(.system(size: 12))
        }
        .padding(.horizontal, 8).padding(.vertical, 6)
        .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 8))
        .padding(.horizontal, 10)
    }

    private func submit() {
        guard let url = settings.searchEngine.resolve(addressText) else { return }
        if let tab = tabs.first(where: { $0.id == selectedTabID }) {
            tab.load(url.absoluteString)
        } else {
            let tab = BrowserTab(urlString: url.absoluteString)
            tabs.append(tab)
            selectedTabID = tab.id
        }
    }

    private func syncAddressBar() {
        addressText = tabs.first(where: { $0.id == selectedTabID })?.urlString ?? ""
    }

    private func newTab() {
        let tab = BrowserTab(urlString: BrowserSettings.shared.homePage)
        tabs.append(tab)
        selectedTabID = tab.id
    }

    private func close(_ tab: BrowserTab) {
        tabs.removeAll { $0.id == tab.id }
        if selectedTabID == tab.id { selectedTabID = tabs.first?.id }
    }
}

private struct TabRow: View {
    @ObservedObject var tab: BrowserTab
    let isSelected: Bool
    let collapsed: Bool

    var body: some View {
        HStack(spacing: 8) {
            faviconView
            if !collapsed {
                Text(tab.title).font(.system(size: 12.5)).lineLimit(1)
                Spacer()
                if tab.isPlayingAudio {
                    Image(systemName: tab.isMuted ? "speaker.slash.fill" : "speaker.wave.2.fill")
                        .font(.system(size: 10)).foregroundStyle(.secondary)
                }
            }
        }
        .padding(.horizontal, collapsed ? 0 : 10)
        .padding(.vertical, 7)
        .frame(maxWidth: .infinity)
        .background(isSelected ? Color.accentColor.opacity(0.18) : Color.clear)
        .clipShape(RoundedRectangle(cornerRadius: 8))
        .help(tab.title)
    }

    @ViewBuilder private var faviconView: some View {
        if let favicon = tab.favicon {
            Image(nsImage: favicon)
                .resizable()
                .frame(width: 14, height: 14)
                .clipShape(RoundedRectangle(cornerRadius: 3))
        } else {
            Image(systemName: tab.faviconSystemName)
                .font(.system(size: 12))
                .frame(width: 14, height: 14)
        }
    }
}
