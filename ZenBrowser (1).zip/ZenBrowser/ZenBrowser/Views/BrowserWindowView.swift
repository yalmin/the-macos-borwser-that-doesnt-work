import SwiftUI

struct BrowserWindowView: View {
    @StateObject private var settings = BrowserSettings.shared
    @State private var tabs: [BrowserTab] = [BrowserTab(urlString: "https://duckduckgo.com")]
    @State private var selectedTabID: UUID?
    @State private var showControlCenter = false
    @State private var showSettingsTab = false
    @State private var themeFlashOpacity: Double = 0

    private var activeTab: BrowserTab? { tabs.first(where: { $0.id == selectedTabID }) }

    var body: some View {
        ZStack(alignment: .topLeading) {
            HStack(spacing: 0) {
                if !settings.sidebarOnRight {
                    SidebarView(settings: settings, tabs: $tabs, selectedTabID: $selectedTabID)
                }
                content
                if settings.sidebarOnRight {
                    SidebarView(settings: settings, tabs: $tabs, selectedTabID: $selectedTabID)
                }
            }

            // Invisible hotspot in the top-left corner. Flicking the mouse
            // here reveals the liquid-glass Control Center.
            Color.clear
                .frame(width: 24, height: 24)
                .contentShape(Rectangle())
                .onHover { hovering in
                    if hovering {
                        withAnimation(.spring(response: 0.32, dampingFraction: 0.85)) { showControlCenter = true }
                    }
                }

            if showControlCenter {
                ControlCenterOverlay(settings: settings, tabs: $tabs, activeTab: activeTab)
                    .onHover { hovering in
                        if !hovering {
                            withAnimation(.easeOut(duration: 0.2)) { showControlCenter = false }
                        }
                    }
            }

            // A soft liquid-glass flash cross-fades over the whole window
            // whenever light/dark mode changes, instead of an instant snap.
            GlassBackground(cornerRadius: 0, intensity: 0.9)
                .opacity(themeFlashOpacity)
                .allowsHitTesting(false)
                .ignoresSafeArea()
        }
        .tint(settings.accentColor)
        .preferredColorScheme(colorScheme)
        .onAppear { selectedTabID = tabs.first?.id }
        .onChange(of: settings.appearance) { _ in
            themeFlashOpacity = 0.85
            withAnimation(.easeOut(duration: 0.55)) { themeFlashOpacity = 0 }
        }
        .onReceive(NotificationCenter.default.publisher(for: .openSettingsTab)) { _ in
            showSettingsTab = true
            withAnimation { showControlCenter = false }
        }
    }

    @ViewBuilder private var content: some View {
        if showSettingsTab {
            SettingsTabView(settings: settings)
                .overlay(alignment: .topTrailing) {
                    Button { showSettingsTab = false } label: { Image(systemName: "xmark.circle.fill") }
                        .buttonStyle(.plain).padding(12)
                }
        } else if let tab = activeTab {
            WebViewRepresentable(tab: tab)
        } else {
            Text("No tab selected").opacity(0.4).frame(maxWidth: .infinity, maxHeight: .infinity)
        }
    }

    private var colorScheme: ColorScheme? {
        switch settings.appearance {
        case .system: return nil
        case .light: return .light
        case .dark: return .dark
        }
    }
}
